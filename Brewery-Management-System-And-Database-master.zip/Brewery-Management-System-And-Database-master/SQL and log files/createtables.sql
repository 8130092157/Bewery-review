\i DROP.sql
\i strongentities.sql
\i weakentities.sql
\i relations.sql

\i beer.sql
\i ingredients.sql
\i equipment.sql
\i employee.sql
\i recipe.sql
\i batch.sql
\i case.sql
\i brewer.sql
\i sales.sql
\i maintenance.sql
\i customer.sql
\i maintains.sql
\i brews.sql
\i purchase.sql


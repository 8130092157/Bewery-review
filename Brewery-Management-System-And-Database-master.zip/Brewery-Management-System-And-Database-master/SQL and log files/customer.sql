INSERT INTO customer VALUES(942136591,'Mr. Poopy Butthole','420blazeit@hotmail.com','1 Ave WALAO',232716130);
INSERT INTO customer VALUES(26493178,'Bev','wakaka@gmail.com','6 Hong Gan Plz',232716130);
INSERT INTO customer VALUES(958685071,'Jerry','youdontknowme@yahoo.com','Area 51',232716130);
INSERT INTO customer VALUES(340733760,'Rick','bigcowstrongchicken@gmail.com','The Jupiter System',232716130);
INSERT INTO customer VALUES(70564146,'Morty','dropitlikeitscold@hotmail.com','Hoth Rebel Base',232716130);
INSERT INTO customer VALUES(596793719,'Summer','zipzap@yahoo.com','221b Baker Street',232716130);

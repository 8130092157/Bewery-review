\i DROP.sql
\i strongentities.sql
\i q8-weakentities.sql
\i relations.sql

INSERT INTO employee VALUES(882007008,'Tynan Davis',314013,'3501 rue University, Quebec, Canada','1103-6-3');
INSERT INTO employee VALUES(782071604,'Alex Wong',944385,'42 Wallaby Way, Sydney, Australia','1204-2-14');
INSERT INTO employee VALUES(232716130,'Simon Hsu',461835,'Wayne Manor, Gotham City, USA','1973-8-11');
INSERT INTO employee VALUES(324512729,'Andrew Tran',714287,'2001 Dark Side, Moon','1422-3-15');
INSERT INTO employee VALUES(100326124,'Steve Jobs',170827,'Cantina, Mos Eisley, Tatooine, Galaxy Far Far Away','1617-7-23');
INSERT INTO employee VALUES(114136446,'Michael Jordan',183161,'Cell 2187, Detention Block AA-23, Death Star, Galaxy Far Far Away','1700-3-20');
